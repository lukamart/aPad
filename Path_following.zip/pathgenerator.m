function [path,x_p,y_p,xlim,ylim,x_s,y_s]=pathgenerator(n,w)
if n==1 %% first scenario
    kk=tand(13);
%     kk=0.0; % koef. koji si koristio
    path=[-w;-kk*w];
%     path=[cos(w);sin(w)]
    x_p=-1; x_s=0;
    y_p=-kk; y_s=0;
    xlim=[0 200];
    ylim=[0 40];
elseif n==2
    path=[4+2.5*sin(w);2.1+cos(w)];
    x_p=2.5*cos(w); x_s=-sin(w);
    y_p=-sin(w); y_s=sin(0.01*w)*0.01;
    xlim=[0 300];
    ylim=[0 300];
elseif n==3
    xw=[50 200 300];
    yw=[0 400 0];
    pp=polyfit(xw,yw,2);
    path=[w;polyval(pp,w)];
    x_p=1; x_s=0;
    y_p=2*pp(1)*w+pp(2); y_s=2*pp(1);
    xlim=[0 450];
    ylim=[0 450];
elseif n==4
     a=50;b=100;c=50;
    path=[80+a*cos(1/c*w);0-b*sin(1/c*w)];
    x_p=-1/c*a*sin(1/c*w); x_s=-cos(1/20*w)*0.1;
    y_p=-1/c*b*cos(1/c*w); y_s=sin(1/20*w)*0.1;
 elseif n==5
    kk=tand(0);
    path=[w;kk*w+10];
    x_p=1; x_s=0;
    y_p=kk; y_s=0;
elseif n==6
    a=19;b=50;c=10;
    path=[w;b*sin(1/c*w)];
    x_p=1; x_s=0;
    y_p=b/c*cos(1/c*w); y_s=-b/c^2*sin(1/c*w);
 end
 xlim=[0 50];
 ylim=[0 50];
end