classdef  VehicleEnum < Simulink.Mask.EnumerationBase
   enumeration
      vis(1, 'vis')
      krk(2, 'krk')
      cres(3, 'cres')
   end
 end