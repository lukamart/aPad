function w=find_w0(x0,N)
dt=0.01;
w=1;
for n=1:1000
    x(:,n)=x0;
    [path{n},x_p(n),y_p(n)]=pathgenerator(N,w(n));
    ksi(n)=atan2(y_p(n),x_p(n));
    xe(n)=[x(1,n)-path{n}(1)]*cos(ksi(n))+[x(2,n)-path{n}(2)]*sin(ksi(n));
    w(n+1)=w(n)+dt*20*[xe(n)]/sqrt(x_p(n)^2+y_p(n)^2);
end
w=w(end);
end