function data=crtajp(vozilo,N)
% load data_2024-06-26_14-29-02.mat
% load data_2024-06-26_15-06-49.mat
% load podaci/27-Jun-2024/2024-06-27_15-11-04.mat
% folder='podaci/28-Jun-2024/';
folder='podaci/05-Jul-2024/';
matFiles = dir([folder vozilo '*.mat']);
[~, sortedIdx] = sort({matFiles.name});
sortedMatFiles = matFiles(sortedIdx);

try 
    load([folder sortedMatFiles(end-N).name])
end
close all
% plot(data.podaci.Data(1,:))
% hold on
% plot(data.manual_enable.Data)
% legend('Algoritam')
% data.eta.Data=data.eta.Data';
figure
t=tiledlayout(2,1);
t.TileSpacing = 'compact';
t.Padding = 'compact';
nexttile
plot(data.podaci.Time,data.podaci.Data(2,:))
hold on
plot(data.podaci.Time,data.podaci.Data(12,:))
plot(data.podaci.Time,data.manual_enable.Data)
legend('$x_e$','$\hat x_e$','joy','interpreter','latex')
try
    en=num2str(data.podaci.Data(18,end));
catch
    en='?';
end

try
    dx=num2str(data.podaci.Data(20,end));
    dy=num2str(data.podaci.Data(21,end));
catch
    dx='?'; dy='?';
end
title(['Alg. ' num2str(data.podaci.Data(1,1)) ', \beta_{enabled}=' en ', dx=' dx ', dy=' dy])
nexttile
plot(data.podaci.Time,data.podaci.Data(3,:))
hold on
plot(data.podaci.Time,data.podaci.Data(13,:))
plot(data.podaci.Time,data.manual_enable.Data)
legend('$y_e$','$\hat y_e$','joy','interpreter','latex')
set(gcf,'position',[875  458  388  260])
figure
t=tiledlayout(1,1);
t.TileSpacing = 'compact';
t.Padding = 'compact';
nexttile
plot(data.podaci.Time,data.podaci.Data(4,:))
hold on
plot(data.podaci.Time,data.eta.Data(3,:))
plot(data.podaci.Time,atan(data.podaci.Data(11,:)./data.podaci.Data(10,:)))
% plot(data.manual_enable.Data)
legend('$\psi_{ref}$','$\psi$','$\alpha$','interpreter','latex')
set(gcf,"Position",[875  56  388  120])
%%
figure
t=tiledlayout(1,1);
t.TileSpacing = 'compact';
t.Padding = 'compact'; 
nexttile
plot(data.podaci.Time,data.podaci.Data(14,:))
hold on
plot(data.podaci.Time,double(data.manual_enable.Data).*0.2)
set(gcf,'Position',[875  257 388 120])
legend('$\beta_{est}$','interpreter','latex')

%%
figure
plot(data.podaci.Time,data.podaci.Data(5,:))
hold on
plot(data.podaci.Time,data.eta.Data(1,:))
plot(data.podaci.Time,data.manual_enable.Data)
legend('$\omega$','$x$','joy','interpreter','latex','Location','northwest')
set(gcf,'Position',[398  578  460 145])
% figure
% plot(data.podaci.Data(6,:))
% legend('U')
figure
plot(data.podaci.Time,data.podaci.Data(7,:))
hold on
plot(data.podaci.Time,data.podaci.Data(8,:))
hold on 
plot(data.podaci.Time,data.manual_enable.Data)
plot(data.podaci.Time,data.nu.Data(1,:))
ylim([-0.5 0.5])
legend('$u_{ref}$','$u_p$','joy','u','interpreter','latex')
set(gcf,'Position',[397.4444  341.4444  461.7778  146.2222])


figure
pozicije=(data.manual_enable.Data==0)'
plot(data.eta.Data(1,pozicije),data.eta.Data(2,pozicije),'.')
hold on
x=0:0.1:8;
% plot(x,3/7*x)
% p=3/7;
% p=[-0.26 1.932 -0.58];
p=[0 3/7 0];
% plot(x,polyval(p,x))
%% putanja path(1,1), path(1,2)
plot(data.podaci.Data(16,pozicije),data.podaci.Data(17,pozicije))
try
%     plot(data.podaci.Data(5,pozicije),data.podaci.Data(17,pozicije)-data.podaci.Data(21,pozicije))
    plot(data.podaci.Data(22,pozicije),data.podaci.Data(23,pozicije))
end
legend('vozilo','ref_vozilo','lider')
set(gcf,'Position',[21.0000  412.5556  358.6667  294.2222])
end