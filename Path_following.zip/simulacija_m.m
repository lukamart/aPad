alpha=0.5;
beta=0;
betaa=3.1;
nu0=0;
nu_t=0.;
poc=0;
% Model parameters
alpha = [0.4,0.4,0.1]';
beta = [0.4,0.4,0.1]';

% Velocity control
% Velocity controller is I-P for surge, sway, yaw-rate
% We use the binomial model function to get the parameters
% Binomial model Gcl wpn for pose PD with binomial closed loop I-P
wpn = [1, 1, 1]';
pcKp = 4*wpn/9;
pcKd = 1/3;
% pcKd=0;
wn = 3*wpn/2;

vcKi = alpha.*wn.^2;
vcKp = 2*alpha.*wn - beta;
vcKt = 1.2*vcKi./vcKp;

%% ovo su parametri drugog kontrolera povecani. tesitati
%vcKp(3)=0.8; 
%vcKi(3)=0.9;

%% usporiti PD ako ne bude radilo
%% ja bih prvo tesirao za fiksni PSI_REF

PD_Kp=2;
PD_Kd=2;
PD_Fil=23.5;

% PD_Kp=0.1;
% PD_Kd=0.1;
% PD_Fil=15;

% Disable velocity controllers for surge and sway
disable = [1,1,1]';
pcKp = pcKp.*disable;
pcKd = pcKd.*disable;

vcKi = vcKi.*disable;
vcKp = vcKp.*disable;
vcKt = vcKt.*disable;

nu_max = [0.5,0.5,1]';
nu_min = -nu_max;
try 
    str=['podaci\' date];
    mkdir(str);
end
filename = ['podaci\' date '\' datestr(now, 'yyyy-mm-dd_HH-MM-SS') '.mat'];
set_param('h2omnix_heading_model/To File10','FileName',filename)
% poc=[0;1;0];
% data=sim('h2omnix_heading_model.slx')
% 
% close all
% plot(data.out.signals.values(:,1),data.out.signals.values(:,2))
% x=0:0.1:10;
% hold on
% 
% w=0:0.1:10*pi;
% koef=1;k1=1;k2=3;
% x=1+k1*cos(koef*w);
% % x=w;
% y=2+k2*sin(koef*w);
% y=2/7*w;x=w;
% plot(x,y);